


<section class="login section-padding">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-5 col-md-12 col-xs-12">
                <div class="login-form login-area">
                    <h3>
                        Verify your account
                    </h3>

                    <p align="center">
                        <?php
                        if($verify_msg != null) {
                            echo $verify_msg;
                        }
                        ?>
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

