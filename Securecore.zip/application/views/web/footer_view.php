<footer>


    <div id="copyright">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="site-info text-center">
                        <p><a target="_blank" href="#">&copy; Secure Core</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

</footer>


<a href="#" class="back-to-top">
    <i class="lni-chevron-up"></i>
</a>

<div id="preloader">
    <div class="loader" id="loader-1"></div>
</div>


<script src="<?php echo base_url(); ?>themes/assets/js/jquery-min.js"></script>
<script src="<?php echo base_url(); ?>themes/assets/js/popper.min.js"></script>
<script src="<?php echo base_url(); ?>themes/assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>themes/assets/js/jquery.counterup.min.js"></script>
<script src="<?php echo base_url(); ?>themes/assets/js/waypoints.min.js"></script>
<script src="<?php echo base_url(); ?>themes/assets/js/wow.js"></script>
<script src="<?php echo base_url(); ?>themes/assets/js/owl.carousel.min.js"></script>
<script src="<?php echo base_url(); ?>themes/assets/js/jquery.slicknav.js"></script>
<script src="<?php echo base_url(); ?>themes/assets/js/main.js"></script>
<script src="<?php echo base_url(); ?>themes/assets/js/form-validator.min.js"></script>
<script src="<?php echo base_url(); ?>themes/assets/js/summernote.js"></script>
</body>


</html>